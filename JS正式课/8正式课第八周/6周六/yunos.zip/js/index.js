~(function () {
    var inner = document.querySelector('.inner');
    var blue = document.querySelectorAll('.blue');
    var yw = document.querySelectorAll('.yw');
    var green = document.querySelectorAll('.green');
    var aDiv = document.querySelectorAll('div');

    inner.onclick = function (e) {
        e = e||window.event;
        var target = e.target||e.srcElement,
            tar = target.tagName.toLowerCase();
        for( i=0;i<aDiv.length;i++){
            var cur1 = aDiv[i];
            utils.removeClass(cur1,'bl')
        }
        if (tar==='div'){
            utils.addClass(target,'bl');
            target.addEventListener('transitionend',function () {
                for (var i = 0; i<aDiv.length;i++){
                    var cur = aDiv[i];
                    if (cur==target){
                        continue;
                    }else {
                        utils.addClass(cur,'bl')
                    }
                }
               setTimeout(function () {
                     for( i=0;i<aDiv.length;i++){
                        var cur1 = aDiv[i];
                        utils.removeClass(cur1,'bl')
                    }
                },1000)

            },false)
        }
    }



})();