(function () {









    /*var music = document.querySelector('.music');
    var beyond = document.querySelector('#beyond');
    window.setTimeout(function () {
        music.style.opacity=1;
        beyond.play();
        music.className = 'music musicMove';
    },1500);
    music.addEventListener('click',function () {
        if (beyond.paused){
            beyond.play();
            music.className = 'music musicMove';
        }else {
            beyond.pause();
            music.className = 'music'
        }
    })*/




})();
