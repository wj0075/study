第一天上午：http协议
第一天的下午：原生ajax

第二天上午：jquery的ajax用法，以及jquery一些注意事项
第二天下午：跨域


https://github.com/YataoZhang/personal_project/blob/master/README.md
https://segmentfault.com/a/1190000007282189
https://segmentfault.com/a/1190000005883614