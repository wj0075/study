/**
 * Created by fdl on 2016/10/15.
 */
document.write('<script src=\'js文件的路径\'></script>');
//单引号不能嵌套单引号    可以用\转译
//双引号不能嵌套双引号
alert('外链式弹出框')
