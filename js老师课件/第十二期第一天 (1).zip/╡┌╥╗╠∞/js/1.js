//document.write('<script src="js文件的路径"></script>');
alert('我是外链式');